1. The files contained within resulted from modifications to the XAPP1079 reference design (for the ZC702) to support Zedboard.

2. ISE 14.5 was used to create the necessary elf files and bitstream specific to ZedBoard

3. The ChipScope project was tested using Chipscope Pro 14.5 successfully.

4. The system.bit file exported to the SDK hardware platform workspace was used to creat the BOOT.BIN file instead of the download.bit file from the implementation directory.  The bif file was modified to support this system.bit file.