
// Stuv for close() sys-call
int $Sub$$_sys_close(int fh)
{
   return -1;
}
