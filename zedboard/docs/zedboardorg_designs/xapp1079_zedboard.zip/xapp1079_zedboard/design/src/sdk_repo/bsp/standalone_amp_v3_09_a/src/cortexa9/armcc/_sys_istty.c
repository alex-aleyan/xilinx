
// Stub for istty sys-call
int $Sub$$_sys_istty(unsigned int* f)
{ 
   /* cannot read/write files */
   return 1;
}
